The following files are licensed under the Creative Commons Attribution-Share Alike 2.5 Generic license
Attribution: Classical Numismatic Group, Inc. http://www.cngcoins.com

- Brutus_Plaetorius_Cestianus_denarius_42_BC_FRONT.png
- Brutus_Plaetorius_Cestianus_denarius_42_BC_BACK.png
- Octavianus_Aegypto_capta_FRONT.png
- Octavianus_Aegypto_capta_BACK.png

