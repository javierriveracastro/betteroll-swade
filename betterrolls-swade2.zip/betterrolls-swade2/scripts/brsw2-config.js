export const MODULE_NAME = "betterrolls-swade2";

// Commented out for future use.
//export const MODULE_TITLE = "Better Rolls";
//export const MODULE_SHORT_TITLE = "BR2";
//export const MODULE_PATH = "modules/betterrolls-swade2";

export const SETTING_KEYS = {
  world_settings: "world_settings",
};

export const USER_FLAGS = {
  user_settings: "user_settings",
};

export const WORLD_SETTINGS = {};
export const USER_SETTINGS = {};
